package com.example.uisocial

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
